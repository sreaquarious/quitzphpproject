<?php
$host = "localhost";
$db_name = "mydatabase";
$username = "root";
$password = "1015";
$connection = null;
try{
$connection = new PDO("mysql:host=" . $host . ";dbname=" . $db_name, $username, $password);
$connection->exec("set names utf8");
}catch(PDOException $exception){
echo "Connection error: " . $exception->getMessage();
}


$name66 =(htmlentities($_GET['name55']));

$insert=("insert into names(name) values('$name66');");
$connection->query($insert);

?>


<html>

<h1>Thank You!!</h1>
<button onclick="window.location.href = 'qn.php'">New Quiz</button>
</html>









