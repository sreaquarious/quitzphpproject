<?php
if(isset($_POST["return"]))
{
header('Location:qn.php');
}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>
Loss page
</title>
</head>
<form name="test" action"" method="post">
<body>
<h1>You are lost.</h1>
<input type="submit" name="return" value="Try Again">
</form>
</body>
</html>



