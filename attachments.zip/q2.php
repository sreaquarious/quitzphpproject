<?php

if(isset($_POST["answer2"]) && ($_POST["submit2"])) 
{
$name22=(htmlentities($_GET['name11']));
$url=("?name22=".$name22);
header('Location:q3.php'.$url);
}
else if(isset($_POST["answer1"]) && ($_POST["submit2"])) 
{
header('Location:loss.php');
}
else if(isset($_POST["answer4"]) && ($_POST["submit2"])) 
{
header('Location:loss.php');
}
else if(isset($_POST["answer3"]) && ($_POST["submit2"])) 
{
header('Location:loss.php');
}

?>

<html>
<head>
<title>
question number 2
</title>
</head>
<form name="test" action="" method="post">
<body>
<h4>2.Which bank is the Banker of the Banks?</h4>
<div>
<input name="answer1" value="South africa" type="radio">UBI
</div>
<div>
<input name="answer2" value="Brazil" type="radio">RBI
</div>
<div>
<input name="answer3" value="Corner Processing Unit" type="radio">PNB
</div>
<div>
<input name="answer4" value="Central Processing Unit" type="radio">SBI
</div>
<div>
<input type="submit" name="submit2" value="submit">
</form>
</body>
</html>

